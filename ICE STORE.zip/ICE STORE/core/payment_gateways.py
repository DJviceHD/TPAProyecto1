class WebPay:
    @staticmethod
    def process(amount): return True

class MACH:
    @staticmethod
    def process(amount): return True

class BancoEstado:
    @staticmethod
    def process(amount): return True

class Transferencia:
    @staticmethod
    def process(amount): return True
